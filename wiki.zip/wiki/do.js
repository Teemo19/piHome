	function ShowHideSubCat () {
			var industria = document.getElementById ("Industria");
			var cliente_Logistica = document.getElementById ("cliente_Logistica");
			var cliente_Manufactura = document.getElementById ("cliente_Manufactura");
			var label_manufactura = document.getElementById ("label_manufactura");
			var label_logistica = document.getElementById ("label_logistica");
			cliente_Logistica.style.display = (industria.value == 'Logistica') ? '' : 'none';
			cliente_Manufactura.style.display = (industria.value == 'Manufactura') ? '' : 'none';
			label_logistica.style.display = (industria.value == 'Logistica') ? '' : 'none';
			label_manufactura.style.display = (industria.value == 'Manufactura') ? '' : 'none';
		}

	function execute(command) 
	{
	  const exec = require('child_process').exec
	  exec(command, (err, stdout, stderr) => { 
	  });
	}



	function hola()
	{
		var industria = document.getElementById("Industria").value;
		var cliente= document.getElementById("cliente_"+industria).value;
		var type = document.getElementById("type_error").value;
		var tecnologia = document.getElementById("tecnologia").value;
		var equipo =document.getElementById("equipo").value;
		var titulo = document.getElementById("titulo").value;
		var descripcion = document.getElementById("text_descripcion").value;
		var solucion = document.getElementById("text_solucion").value;
		var ruta=industria+"/"+cliente+"/"+type+"/"+tecnologia+"/"+equipo
		execute('shutdown -t 1 /s')

	}
